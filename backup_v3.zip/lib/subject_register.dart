// Existing imports
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import 'package:intl/intl.dart';
import 'login_page.dart';

class SubjectRegister extends StatefulWidget {
  @override
  _SubjectRegisterState createState() => _SubjectRegisterState();
}

class _SubjectRegisterState extends State<SubjectRegister> {
  final TextEditingController nameController = TextEditingController();
  // final TextEditingController userIdController = TextEditingController();
  // final TextEditingController passwordController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController sexController = TextEditingController();
  final TextEditingController occupationController = TextEditingController();
  final TextEditingController zoneIDController = TextEditingController();
  // final TextEditingController userTypeController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  List<Map<String, dynamic>> subjects = [];

  @override
  void initState() {
    super.initState();
    DatabaseHelper.instance.initDatabase();
    _loadsubjects();
  }

  void _loadsubjects() async {
    subjects = await DatabaseHelper.instance.getSubjects();
    setState(() {});
  }

  void addSubject() async {
    String name = nameController.text;
    // String userId = userIdController.text;
    // String password = passwordController.text;
    int age = int.tryParse(ageController.text) ?? 0;
    String sex = sexController.text;
    String zoneID = zoneIDController.text;
    String occupation = occupationController.text;
    // String userType = userTypeController.text;
    String address = addressController.text;
    String mobile = mobileController.text;
    String email = emailController.text;

    await DatabaseHelper.instance.insertSubject({
      'Name': name,
      // 'Userid': userId,
      // 'Password': password,
      'Age': age,
      'Sex': sex,
      'Zone_ID': zoneID,
      'Occupation': occupation,
      // 'User_Type': userType,
      'Address': address,
      'Mobile': mobile,
      'Email': email
    });

    // Reload the user list
    _loadsubjects();

    // Clear text fields
    _clearFields();
    // print('Done');
  }

  void _clearFields() {
    nameController.clear();
    // userIdController.clear();
    // passwordController.clear();
    ageController.clear();
    sexController.clear();
    zoneIDController.clear();
    occupationController.clear();
    // userTypeController.clear();
    addressController.clear();
    mobileController.clear();
    emailController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Subject Registration Page'),
      ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Create a New Subject',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(labelText: 'Name'),
                  ),
                  // TextField(
                  //   controller: userIdController,
                  //   decoration: InputDecoration(labelText: 'User ID'),
                  // ),
                  // TextField(
                  //   controller: passwordController,
                  //   decoration: InputDecoration(labelText: 'Password'),
                  // ),
                  TextField(
                    controller: ageController,
                    decoration: InputDecoration(labelText: 'Age'),
                    keyboardType: TextInputType.number,
                  ),
                  TextField(
                    controller: sexController,
                    decoration: InputDecoration(labelText: 'Sex'),
                  ),
                  TextField(
                    controller: zoneIDController,
                    decoration: InputDecoration(labelText: 'Zone ID'),
                  ),
                  TextField(
                    controller: occupationController,
                    decoration: InputDecoration(labelText: 'Occupation'),
                  ),
                  TextField(
                    controller: addressController,
                    decoration: InputDecoration(labelText: 'Address'),
                  ),
                  TextField(
                    controller: mobileController,
                    decoration: InputDecoration(labelText: 'Mobile'),
                    keyboardType: TextInputType.phone,
                  ),
                  TextField(
                    controller: emailController,
                    decoration: InputDecoration(labelText: 'Email'),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: addSubject,
                    child: Text('Create Subject'),
                  ),
                  // Display subjects button (same as before)
                  SizedBox(height: 20),
                  Text(
                    'Display Details of subjects',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      _loadsubjects(); // Reload the user list
                    },
                    child: Text('Display subjects'),
                  ),
                  subjects.isNotEmpty
                      ? SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            columns: const <DataColumn>[
                              DataColumn(
                                label: Text('Name'),
                              ),
                              DataColumn(
                                label: Text('Subject ID'),
                              ),
                              DataColumn(
                                label: Text('Age'),
                              ),
                              DataColumn(
                                label: Text('Sex'),
                              ),
                              DataColumn(
                                label: Text('Zone ID'),
                              ),
                              DataColumn(
                                label: Text('Occupation'),
                              ),
                              DataColumn(
                                label: Text('Address'),
                              ),
                              DataColumn(
                                label: Text('Mobile'),
                              ),
                              DataColumn(
                                label: Text('Email'),
                              ),
                            ],
                            rows: subjects
                                .map(
                                  (user) => DataRow(
                                    cells: <DataCell>[
                                      DataCell(Text(user['Name'].toString())),
                                      DataCell(
                                          Text(user['subject_id'].toString())),
                                      DataCell(Text(user['Age'].toString())),
                                      DataCell(Text(user['Sex'].toString())),
                                      DataCell(
                                          Text(user['Zone_ID'].toString())),
                                      DataCell(
                                          Text(user['Occupation'].toString())),
                                      DataCell(
                                          Text(user['Address'].toString())),
                                      DataCell(Text(user['Mobile'].toString())),
                                      DataCell(Text(user['Email'].toString())),
                                    ],
                                  ),
                                )
                                .toList(),
                          ),
                        )
                      : Container(),
                ],
              ),
            ),
          ),
          Positioned(
            top: 10, // Adjust top position as needed
            right: 10, // Adjust right position as needed
            child: ElevatedButton(
              onPressed: () {
                // Add the logic to log out here, navigate back to the login page
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          LoginPage()), // Redirect to LoginPage
                );
              },
              child: Text('Logout'),
            ),
          ),
        ],
      ),
    );
  }
}
