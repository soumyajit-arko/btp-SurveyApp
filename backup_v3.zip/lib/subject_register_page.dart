// Existing imports
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import 'package:intl/intl.dart';
import 'login_page.dart';

class SubjectRegisterPage extends StatefulWidget {
  @override
  _SubjectRegisterPageState createState() => _SubjectRegisterPageState();
}

class _SubjectRegisterPageState extends State<SubjectRegisterPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController sexController = TextEditingController();
  final TextEditingController occupationController = TextEditingController();
  final TextEditingController zoneIDController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  List<Map<String, dynamic>> subjects = [];

  @override
  void initState() {
    super.initState();
    DatabaseHelper.instance.initDatabase();
  }

  void addSubject() async {
    String name = nameController.text;
    // String userId = userIdController.text;
    // String password = passwordController.text;
    int age = int.tryParse(ageController.text) ?? 0;
    String sex = sexController.text;
    String zoneID = zoneIDController.text;
    String occupation = occupationController.text;
    // String userType = userTypeController.text;
    String address = addressController.text;
    String mobile = mobileController.text;
    String email = emailController.text;

    await DatabaseHelper.instance.insertSubject({
      'Name': name,
      // 'Userid': userId,
      // 'Password': password,
      'Age': age,
      'Sex': sex,
      'Zone_ID': zoneID,
      'Occupation': occupation,
      // 'User_Type': userType,
      'Address': address,
      'Mobile': mobile,
      'Email': email
    });

    // Clear text fields
    _clearFields();
    // print('Done');
  }

  void _clearFields() {
    nameController.clear();
    // userIdController.clear();
    // passwordController.clear();
    ageController.clear();
    sexController.clear();
    zoneIDController.clear();
    occupationController.clear();
    // userTypeController.clear();
    addressController.clear();
    mobileController.clear();
    emailController.clear();
  }

  Widget _buildSmallTextField(
      TextEditingController controller, String labelText,
      {TextInputType? keyboardType}) {
    return Container(
      width: 200, // Set the desired width
      height: 50,
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: labelText,
          border: OutlineInputBorder(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Subject Registration Page'),
      ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Create a New Subject',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  _buildSmallTextField(nameController, 'Name'),
                  SizedBox(height: 10),
                  _buildSmallTextField(ageController, 'Age',
                      keyboardType: TextInputType.number),
                  SizedBox(height: 10),
                  _buildSmallTextField(sexController, 'Sex'),
                  SizedBox(height: 10),
                  _buildSmallTextField(zoneIDController, 'Zone ID'),
                  SizedBox(height: 10),
                  _buildSmallTextField(occupationController, 'Occupation'),
                  SizedBox(height: 10),
                  _buildSmallTextField(addressController, 'Address'),
                  SizedBox(height: 10),
                  _buildSmallTextField(mobileController, 'Mobile',
                      keyboardType: TextInputType.phone),
                  SizedBox(height: 10),
                  _buildSmallTextField(emailController, 'Email'),

                  SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: addSubject,
                    icon: Icon(Icons.person,
                        size: 30), // Add a "person" icon for the subject
                    label: Text('Create Subject'),
                  )

                  // Display subjects button (same as before)
                ],
              ),
            ),
          ),
          Positioned(
            top: 10, // Adjust top position as needed
            right: 10, // Adjust right position as needed
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginPage(),
                  ),
                );
              },
              icon: Icon(Icons.logout, size: 30), // Add a logout icon
              label: Text('Logout'),
            ),
          ),
        ],
      ),
    );
  }
}
