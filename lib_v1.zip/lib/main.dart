// main.dart

import 'package:flutter/material.dart';
import 'design_executive.dart';
import 'survey_page.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  runApp(const MaterialApp(
    home: MainPage(),
  ));
}

class MainPage extends StatelessWidget {
  const MainPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Main Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                // Navigate to the second page when the button is pressed
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) =>
                        QuestionnaireBuilder(), // Use the SecondPage widget
                  ),
                );
              },
              child: const Text('Go to Design Executive Page'),
            ),
            ElevatedButton(
              onPressed: () {
                // Navigate to the Third Page
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => SurveyPage(),
                  ),
                );
              },
              child: const Text('Go to Survey taker Page'),
            ),
            // ElevatedButton(
            //   onPressed: () {
            //     // Navigate to the Fourth Page
            //     Navigator.of(context).push(
            //       MaterialPageRoute(
            //         builder: (context) => FourthPage(),
            //       ),
            //     );
            //   },
            //   child: Text('Go to Admin Page'),
            // ),
          ],
        ),
      ),
    );
  }
}
