import 'package:flutter/material.dart';
import 'dart:convert';
import 'database_helper.dart';
import 'dart:io';

class QuestionnaireBuilder extends StatefulWidget {
  @override
  _QuestionnaireBuilderState createState() => _QuestionnaireBuilderState();
}

class _QuestionnaireBuilderState extends State<QuestionnaireBuilder> {
  List<Map<String, dynamic>> questions = [];
  String? selectedType = 'Single Choice';
  List<String> options = [];
  TextEditingController questionController = TextEditingController();
  TextEditingController optionController = TextEditingController();
  List<TextEditingController> optionControllers = [];

  @override
  void dispose() {
    questionController.dispose();
    optionController.dispose();
    super.dispose();
  }

  Map<String, dynamic> deepCopyQuestion(Map<String, dynamic> originalQuestion) {
    return {
      'question': originalQuestion['question'],
      'type': originalQuestion['type'],
      'options': List<String>.from(originalQuestion['options']),
    };
  }

  void addQuestion() {
    if (questionController.text.isNotEmpty) {
      final question = {
        'question': questionController.text,
        'type': selectedType,
        'options': options,
      };
      Map<String, dynamic> q = deepCopyQuestion(question);
      setState(() {
        questions.add(q);
        questionController.clear();
        optionControllers.clear();
        options.clear();
        optionControllers.add(TextEditingController());
      });
    }
  }

  void saveQuestionsAsJson(BuildContext context) async {
    final questionnaire = {'questions': questions};
    final jsonText = json.encode(questionnaire);
    print(jsonText);
    final file = File('assets/survey_questions.json');
    await file.writeAsString(jsonText);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Questionnaire saved as JSON file.'),
      ),
    );
  }

  Future<void> saveQuestionsToDatabase() async {
    final database = await DatabaseHelper.instance.database;
    final batch = database.batch();

    for (final question in questions) {
      batch.insert('questions', {
        'question': question['question'],
        'type': question['type'],
        'options': jsonEncode(question['options']),
      });
    }

    await batch.commit();
    print('saved successfully in database');
  }

  Future<void> retrieveDataFromDatabase() async {
    final questions = await DatabaseHelper.instance.getQuestions();

    // Now you have a list of questions from the database
    print('Retrieved questions: $questions');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            const Text(
              'Select the type of question:',
              style: TextStyle(fontSize: 18),
            ),
            DropdownButton<String>(
              value: selectedType,
              icon: const Icon(Icons.arrow_drop_down),
              style: const TextStyle(color: Colors.blue, fontSize: 18),
              underline: Container(
                height: 2,
                color: Colors.blue,
              ),
              items: <String>[
                'Single Choice',
                'Multiple Choice',
                'Text Answer',
                'Integer Answer',
              ].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(
                    value,
                    style: const TextStyle(fontSize: 18),
                  ),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedType = newValue;
                  options.clear();
                });
              },
            ),
            const Text(
              'Enter the question:',
              style: TextStyle(fontSize: 18),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: questionController,
                decoration: const InputDecoration(
                  labelText: 'Question',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            if (selectedType == 'Single Choice' ||
                selectedType == 'Multiple Choice')
              Column(
                children: <Widget>[
                  const Text(
                    'Enter options:',
                    style: TextStyle(fontSize: 18),
                  ),
                  for (var i = 0; i < options.length; i++)
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: optionControllers[
                            i], // Use the respective controller
                        onChanged: (text) {
                          options[i] = text;
                        },
                        decoration:
                            InputDecoration(labelText: 'Option ${i + 1}'),
                      ),
                    ),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        options.add('');
                        optionControllers.add(
                            TextEditingController()); // Add a new controller
                      });
                    },
                    child: const Text('Add Option'),
                  ),
                ],
              ),
            ElevatedButton(
              onPressed: addQuestion,
              child: const Text('Add Question'),
            ),
            ElevatedButton(
              onPressed: () {
                saveQuestionsAsJson(context);
              },
              child: const Text('Save Questions as JSON'),
            ),
            ElevatedButton(
              onPressed: () async {
                await saveQuestionsToDatabase();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Questionnaire saved to the database.'),
                  ),
                );
              },
              child: const Text('Save Questions to Database'),
            ),
            ElevatedButton(
              onPressed: () async {
                await retrieveDataFromDatabase();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Questionnaire retrieved from the database.'),
                  ),
                );
              },
              child: const Text('Retrieve Questions from Database'),
            ),
            if (questions.isNotEmpty)
              Column(
                children: <Widget>[
                  const Text(
                    'Questions:',
                    style: TextStyle(fontSize: 20),
                  ),
                  ListView.builder(
                    shrinkWrap: true,
                    itemCount: questions.length,
                    itemBuilder: (context, index) {
                      final question = questions[index];
                      final type = question['type'];
                      final questionText = question['question'];
                      final optionsList = question['options'] as List<String>;

                      return ListTile(
                        title: Text('Question: $questionText'),
                        subtitle: Text(
                            'Type: $type\nOptions: ${optionsList.join(", ")}'),
                      );
                    },
                  ),
                ],
              ),
            ElevatedButton(
              onPressed: () {
                // Navigate back to the main page when the "Go Back" button is pressed
                Navigator.of(context).pop();
              },
              child: const Text('Go Back to Main Page'),
            ),
          ],
        ),
      ),
    );
  }
}
