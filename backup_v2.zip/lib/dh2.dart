// import 'package:sqflite/sqflite.dart';
// import 'package:path/path.dart';

// class DatabaseHelper {
//   DatabaseHelper._privateConstructor();
//   static final DatabaseHelper instance = DatabaseHelper._privateConstructor();
//   Database? _database;

//   Future<Database> get database async {
//     if (_database != null) return _database!;

//     _database = await initDatabase();
//     return _database!;
//   }

//   Future<Database> initDatabase() async {
//     final dbpath = await getDatabasesPath();
//     print(dbpath);
//     String path = join(dbpath, 'questionnaire.db');
//     return await openDatabase(path, version: 1, onCreate: _createDb);
//   }

//   Future<void> _createDb(Database db, int version) async {
//     // Create the survey_project table
//     await db.execute('''
//       CREATE TABLE survey_project(
//         sid TEXT PRIMARY KEY,
//         Name TEXT,
//         creation_date DATE,
//         Description TEXT,
//         template_source TEXT
//       )
//     ''');

//     // Create the field_project table with a foreign key reference to survey_project
//     await db.execute('''
//       CREATE TABLE field_project(
//         fid TEXT PRIMARY KEY,
//         sid TEXT,
//         attribute_name TEXT,
//         attribute_datatype TEXT,
//         attribute_unit TEXT,
//         required_value BOOLEAN,
//         InstanceTime CURRENT_TIMESTAMP,
//         FOREIGN KEY (sid) REFERENCES survey_project(sid)
//       )
//     ''');
//   }

//   // Insert a new survey project
//   Future<int> insertSurveyProject(Map<String, dynamic> project) async {
//     final db = await database;
//     return await db.insert('survey_project', project);
//   }

//   // Insert a new field project
//   Future<int> insertFieldProject(Map<String, dynamic> project) async {
//     final db = await database;
//     return await db.insert('field_project', project);
//   }

//   // Update an existing survey project
//   Future<int> updateSurveyProject(String sid, Map<String, dynamic> updatedProject) async {
//     final db = await database;
//     return await db.update('survey_project', updatedProject, where: 'sid = ?', whereArgs: [sid]);
//   }

//   // Update an existing field project
//   Future<int> updateFieldProject(String fid, Map<String, dynamic> updatedProject) async {
//     final db = await database;
//     return await db.update('field_project', updatedProject, where: 'fid = ?', whereArgs: [fid]);
//   }

//   // Delete a survey project
//   Future<int> deleteSurveyProject(String sid) async {
//     final db = await database;
//     return await db.delete('survey_project', where: 'sid = ?', whereArgs: [sid]);
//   }

//   // Delete a field project
//   Future<int> deleteFieldProject(String fid) async {
//     final db = await database;
//     return await db.delete('field_project', where: 'fid = ?', whereArgs: [fid]);
//   }

//   // Retrieve all survey projects
//   Future<List<Map<String, dynamic>>> getSurveyProjects() async {
//     final db = await database;
//     return await db.query('survey_project');
//   }

//   // Retrieve all field projects
//   Future<List<Map<String, dynamic>>> getFieldProjects() async {
//     final db = await database;
//     return await db.query('field_project');
//   }
// }
