import 'package:flutter/material.dart';
import 'database_helper.dart';

class TestPage extends StatefulWidget {
  const TestPage({super.key});

  @override
  State<TestPage> createState() => _TestPageState();
}

class _TestPageState extends State<TestPage> {
  final TextEditingController formNameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController templateController = TextEditingController();
  List<Map<String, dynamic>> formsList = [];

  @override
  void init() {
    super.initState();
    _loadForms();
  }

  void _loadForms() async {
    formsList = await DatabaseHelper.instance.getForms();
    setState(() {});
  }

  void createForm() async {
    String formName = formNameController.text;
    String description = descriptionController.text;
    String template = templateController.text;

    await DatabaseHelper.instance.insertForm({
      'Name': formName,
      'Description': description,
      'template_source': template
    });
    _loadForms();
    _clearFields();
  }

  void _clearFields() async {
    formNameController.clear();
    descriptionController.clear();
    templateController.clear();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Form'),
      ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Center(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text('Enter Form Details'),
                SizedBox(
                  height: 10,
                ),
                TextField(
                  controller: formNameController,
                  decoration: InputDecoration(labelText: 'Form Name'),
                ),
                TextField(
                  controller: descriptionController,
                  decoration: InputDecoration(labelText: 'Description'),
                ),
                SizedBox(
                  height: 20,
                ),
                TextField(
                  controller: templateController,
                  decoration: InputDecoration(labelText: 'Template'),
                ),
                ElevatedButton(
                    onPressed: createForm, child: Text('Create Form')),
                ElevatedButton(
                    onPressed: _loadForms, child: Text('Display Forms')),
                formsList.isNotEmpty
                    ? SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          columns: const <DataColumn>[
                            DataColumn(label: Text('sid')),
                            DataColumn(label: Text('Name')),
                            DataColumn(label: Text('Description')),
                            DataColumn(label: Text('template_source')),
                            DataColumn(label: Text('date_creation')),
                          ],
                          rows: formsList
                              .map(
                                (form_) => DataRow(
                                  cells: <DataCell>[
                                    DataCell(Text(form_['sid'].toString())),
                                    DataCell(Text(form_['Name'].toString())),
                                    DataCell(
                                        Text(form_['Description'].toString())),
                                    DataCell(Text(
                                        form_['template_source'].toString())),
                                    DataCell(Text(
                                        form_['creation_date'].toString())),
                                  ],
                                ),
                              )
                              .toList(),
                        ),
                      )
                    : Container(),
              ],
            )),
          )
        ],
      ),
    );
  }
}
