import 'package:app_001/survey_page.dart';
import 'package:flutter/material.dart';
import 'login_page.dart'; // Import your login page
import 'database_helper.dart'; // Import your database helper
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'design_executive.dart';
import 'test_page.dart';
import 'subject_register.dart';

void main() {
  sqfliteFfiInit(); // Initialize sqflite for FFI
  // sqfliteInitAsMockMethodCall(); // Initialize sqflite as a mock method call
  databaseFactory = databaseFactoryFfi;
  final dbHelper = DatabaseHelper.instance;
  dbHelper.initDatabase();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login App',
      home: LoginPage(),
      // home: TestPage(), // Set your login page as the home page
      // home: SurveyorPage(100),
      // home: SubjectRegister(),
    );
  }
}
