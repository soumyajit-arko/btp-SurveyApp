import 'package:flutter/material.dart';
import 'database_helper.dart';

class SurveyorPage extends StatefulWidget {
  @override
  _SurveyorPageState createState() => _SurveyorPageState();
}

class _SurveyorPageState extends State<SurveyorPage> {
  late Future<List<String>> _formNames;
  List<Map<String, dynamic>> _formDetails = [];
  String? _selectedName; // Initialize with null
  @override
  void initState() {
    super.initState();
    _loadFormNames();
  }

  void _loadFormNames() {
    _formNames = DatabaseHelper.instance.getFormsNames();
  }

  void printSelectedName() async {
    print(_selectedName);
    print('Initial');
    print(_formDetails);
    print('Final');
  }

  void displayForm() async {
    final details =
        await DatabaseHelper.instance.getFormWithName(_selectedName!);
    setState(() {
      _formDetails = details;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Drop-Down Button Example'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          FutureBuilder<List<String>>(
            future: _formNames,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const CircularProgressIndicator(); // Show a loading indicator while data is being fetched.
              } else if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              } else {
                if (snapshot.hasData) {
                  List<String>? formNames = snapshot.data;
                  return DropdownButton<String>(
                    value: _selectedName,
                    items: formNames
                        ?.map((String name) => DropdownMenuItem<String>(
                              value: name,
                              child: Text(name),
                            ))
                        .toList(),
                    onChanged: (String? selectedName) {
                      setState(() {
                        if (selectedName != null) {
                          _selectedName = selectedName;
                          // Do something with the selected name.
                        }
                      });
                    },
                  );
                } else {
                  return Text('No data available');
                }
              }
            },
          ),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(
            onPressed: printSelectedName,
            child: Text('Print Selected Name'),
          ),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(
            onPressed: displayForm,
            child: Text('Display the form'),
          ),
          _formDetails.isNotEmpty
              ? SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: const <DataColumn>[
                      DataColumn(label: Text('sid')),
                      DataColumn(label: Text('Name')),
                      DataColumn(label: Text('Description')),
                      DataColumn(label: Text('template_source')),
                      DataColumn(label: Text('date_creation')),
                    ],
                    rows: _formDetails
                        .map(
                          (form_) => DataRow(
                            cells: <DataCell>[
                              DataCell(Text(form_['sid'].toString())),
                              DataCell(Text(form_['Name'].toString())),
                              DataCell(Text(form_['Description'].toString())),
                              DataCell(
                                  Text(form_['template_source'].toString())),
                              DataCell(Text(form_['creation_date'].toString())),
                            ],
                          ),
                        )
                        .toList(),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
