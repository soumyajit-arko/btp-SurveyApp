// import 'package:sqflite/sqflite.dart';
// import 'package:path/path.dart';

// class DatabaseHelper {
//   DatabaseHelper._privateConstructor();
//   static final DatabaseHelper instance = DatabaseHelper._privateConstructor();
//   Database? _database;

//   Future<Database> get database async {
//     if (_database != null) return _database!;

//     _database = await initDatabase();
//     return _database!;
//   }

//   Future<Database> initDatabase() async {
//     final dbpath = await getDatabasesPath();
//     print(dbpath);
//     String path = join(dbpath, 'questionnaire.db');
//     return await openDatabase(path, version: 1, onCreate: _createDb);
//   }

//   Future<void> _createDb(Database db, int version) async {
//     await db.execute('''
//       CREATE TABLE questions(
//         id INTEGER PRIMARY KEY AUTOINCREMENT,
//         question TEXT,
//         type TEXT,
//         options TEXT
//       )
//     ''');
//   }

//   // Insert a new question
//   Future<int> insertQuestion(Map<String, dynamic> question) async {
//     final db = await database;
//     return await db.insert('questions', question);
//   }

//   // Update an existing question
//   Future<int> updateQuestion(
//       int id, Map<String, dynamic> updatedQuestion) async {
//     final db = await database;
//     return await db
//         .update('questions', updatedQuestion, where: 'id = ?', whereArgs: [id]);
//   }

//   // Delete a question
//   Future<int> deleteQuestion(int id) async {
//     final db = await database;
//     return await db.delete('questions', where: 'id = ?', whereArgs: [id]);
//   }

//   // Retrieve all questions
//   Future<List<Map<String, dynamic>>> getQuestions() async {
//     final db = await database;
//     return await db.query('questions');
//   }

  
// }
