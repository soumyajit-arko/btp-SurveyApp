import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'dart:convert';

import 'login_page.dart';

class SurveyorPage extends StatefulWidget {
  final int tempData;
  SurveyorPage(this.tempData);
  @override
  _SurveyorPageState createState() => _SurveyorPageState();
}

class _SurveyorPageState extends State<SurveyorPage> {
  late Future<List<String>> _formNames;
  late Future<List<String>> _subjectNames;
  List<Map<String, dynamic>> _formDetails = [];
  List<Map<String, dynamic>> questions = [];
  Map<String, dynamic> responses = {};
  String? _selectedName;
  String? _selectedSubject;

  // List<TextEditingController> textControllers = [];
  // int count = 0;
  @override
  void initState() {
    super.initState();
    _loadFormNames();
  }

  void _loadFormNames() {
    _formNames = DatabaseHelper.instance.getFormsNames();
    _subjectNames = DatabaseHelper.instance.getSubjectNames();
  }

  void printSelectedName() async {
    print(_selectedName);
    print('Initial');
    print(_formDetails);
    print('Final');
    print(widget.tempData);
  }

  void displayForm() async {
    final details =
        await DatabaseHelper.instance.getFormWithName(_selectedName!);

    final jsonContent = details[0]['template_source'];
    // Map<String, dynamic> surveyData = json.decode(jsonContent);
    print(jsonContent);
    print("${jsonContent.runtimeType}");
    final data = json.decode(jsonContent);
    print(data);
    print("${data.runtimeType}");
    List<Map<String, dynamic>> mapList =
        data.cast<Map<String, dynamic>>().toList();
    print(mapList);

    setState(() {
      _formDetails = details;
      questions = mapList;
    });
  }

  void handleOptionSelected(String question, String selectedOption) {
    setState(() {
      responses[question] = selectedOption;
    });
  }

  void handleMultipleChoiceOptionSelected(
      String question, String option, bool selected) {
    setState(() {
      if (responses[question] != null) {
        // If a response already exists, append the new option with a comma
        responses[question] = '${responses[question]}, $option';
      } else {
        responses[question] = option;
      }
    });
  }

  void saveResponse() async {
    final responsesMap = Map<String, dynamic>.from(responses);
    final responsesJson = json.encode(responsesMap);
    final subjectID =
        await DatabaseHelper.instance.getsubjectIDByName(_selectedSubject!);
    final sid_ = await DatabaseHelper.instance.getSidByName(_selectedName!);
    final subID = int.parse(subjectID);
    final sid = int.parse(sid_);
    DateTime now = DateTime.now();
    print(subjectID);
    print(responsesJson);
    for (var key in responsesMap.keys) {
      dynamic value = responsesMap[key];
      print('Key: $key, Value: $value');
    }
    final formattedDatetime = now.toUtc().toIso8601String();

    await DatabaseHelper.instance.insertResponse({
      'subject_id': subID,
      'survey_datetime': formattedDatetime,
      'sid': sid,
      'survey_data': responsesJson,
    });

    final rid_ =
        await DatabaseHelper.instance.getridBysubjectIDandDatetime(subID, now);
    print(rid_);
    final rid = int.parse(rid_);
    for (var key in responsesMap.keys) {
      dynamic value = responsesMap[key];
      final fid_ =
          await DatabaseHelper.instance.getfidBysidandAttributeName(sid, key);
      print(fid_);
      final fid = int.parse(fid_);
      await DatabaseHelper.instance.insertFieldEntry({
        'rid': rid,
        'fid': fid,
        'value': value,
      });
      // print('Key: $key, Value: $value');
    }
    print('done');
    // for (int i = 0; i < textControllers.length; ++i) {
    //   textControllers[i].clear();
    //   print('successfully cleared');
    // }

    setState(() {
      responses = {};
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Drop-Down Button Example'),
      ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FutureBuilder<List<String>>(
                  future: _subjectNames,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const CircularProgressIndicator();
                    } else if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    } else {
                      if (snapshot.hasData) {
                        List<String>? formNames = snapshot.data;
                        return Row(
                          children: [
                            Text('Select Subject:'), // Add a label here
                            SizedBox(width: 10), // Add some spacing
                            DropdownButton<String>(
                              value: _selectedSubject,
                              items: formNames
                                  ?.map(
                                      (String name) => DropdownMenuItem<String>(
                                            value: name,
                                            child: Text(name),
                                          ))
                                  .toList(),
                              onChanged: (String? selectedSubject) {
                                setState(() {
                                  if (selectedSubject != null) {
                                    _selectedSubject = selectedSubject;
                                    // Do something with the selected name.
                                  }
                                });
                              },
                            ),
                          ],
                        );
                      } else {
                        return Text('No data available');
                      }
                    }
                  },
                ),
                FutureBuilder<List<String>>(
                  future: _formNames,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const CircularProgressIndicator(); // Show a loading indicator while data is being fetched.
                    } else if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    } else {
                      if (snapshot.hasData) {
                        List<String>? formNames = snapshot.data;
                        return Row(
                          children: [
                            Text('Select Form:'), // Add a label here
                            SizedBox(width: 10), // Add some spacing
                            DropdownButton<String>(
                              value: _selectedName,
                              items: formNames
                                  ?.map(
                                      (String name) => DropdownMenuItem<String>(
                                            value: name,
                                            child: Text(name),
                                          ))
                                  .toList(),
                              onChanged: (String? selectedName) {
                                setState(() {
                                  if (selectedName != null) {
                                    _selectedName = selectedName;
                                    // Do something with the selected name.
                                  }
                                });
                              },
                            ),
                          ],
                        );
                      } else {
                        return Text('No data available');
                      }
                    }
                  },
                ),
                SizedBox(
                  height: 20,
                ),
                ElevatedButton(
                  onPressed: printSelectedName,
                  child: Text('Print Selected Name'),
                ),
                SizedBox(
                  height: 20,
                ),
                ElevatedButton(
                  onPressed: displayForm,
                  child: Text('Display the form'),
                ),
                _formDetails.isNotEmpty
                    ? SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          columns: const <DataColumn>[
                            DataColumn(label: Text('sid')),
                            DataColumn(label: Text('Name')),
                            DataColumn(label: Text('Description')),
                            DataColumn(label: Text('template_source')),
                            DataColumn(label: Text('date_creation')),
                          ],
                          rows: _formDetails
                              .map(
                                (form_) => DataRow(
                                  cells: <DataCell>[
                                    DataCell(Text(form_['sid'].toString())),
                                    DataCell(Text(form_['Name'].toString())),
                                    DataCell(
                                        Text(form_['Description'].toString())),
                                    DataCell(Text(
                                        form_['template_source'].toString())),
                                    DataCell(Text(
                                        form_['creation_date'].toString())),
                                  ],
                                ),
                              )
                              .toList(),
                        ),
                      )
                    : Container(),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 400,
                  child: ListView.builder(
                    itemCount: questions.length,
                    itemBuilder: (context, index) {
                      final question = questions[index];
                      final questionText = question['question'];
                      final questionType = question['type'];
                      final options_ = question['options'];
                      final options = options_.split(',');
                      FocusNode textFocus = FocusNode();
                      Widget? questionWidget;
                      if (questionType == 'Single Choice') {
                        questionWidget = Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(questionText, style: TextStyle(fontSize: 18)),
                            for (var option in options)
                              RadioListTile<String>(
                                title: Text(option),
                                value: option,
                                groupValue: responses[questionText],
                                onChanged: (value) {
                                  handleOptionSelected(
                                      questionText, value ?? '');
                                },
                              ),
                          ],
                        );
                      } else if (questionType == 'Multiple Choice') {
                        questionWidget = Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(questionText, style: TextStyle(fontSize: 18)),
                            for (var option in options)
                              CheckboxListTile(
                                title: Text(option),
                                value:
                                    responses[questionText]?.contains(option) ??
                                        false,
                                onChanged: (selected) {
                                  if (selected != null) {
                                    handleMultipleChoiceOptionSelected(
                                        questionText, option, selected);
                                  }
                                },
                              ),
                          ],
                        );
                      } else if (questionType == 'Text Answer' ||
                          questionType == 'Integer Answer') {
                        // final tempUtil = TextEditingController();
                        // textControllers.add(tempUtil);
                        // count++;
                        questionWidget = Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(questionText, style: TextStyle(fontSize: 18)),
                            TextField(
                              // controller: textControllers[count - 1],
                              enabled: true,
                              style:
                                  TextStyle(color: Colors.black, fontSize: 16),
                              focusNode:
                                  textFocus, // Assign the FocusNode to the TextField
                              onChanged: (value) {
                                print('The text is: $value');
                                handleOptionSelected(questionText, value);
                              },
                              onTap: () {
                                textFocus
                                    .requestFocus(); // Focus the TextField when tapped
                              },
                              decoration: InputDecoration(
                                  hintText: 'Enter your answer'),
                            ),
                          ],
                        );
                      }

                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: questionWidget,
                      );
                    },
                  ),
                ),
                ElevatedButton(
                    onPressed: saveResponse, child: Text('Save Response')),
              ],
            ),
          ),
          Positioned(
            top: 10, // Adjust top position as needed
            right: 10, // Adjust right position as needed
            child: ElevatedButton(
              onPressed: () {
                // Add the logic to log out here, navigate back to the login page
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginPage(), // Redirect to LoginPage
                  ),
                );
              },
              child: Text('Logout'),
            ),
          ),
        ],
      ),
    );
  }
}
