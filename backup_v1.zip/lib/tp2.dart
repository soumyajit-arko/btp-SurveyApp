// import 'package:flutter/material.dart';
// import 'database_helper.dart';
// import 'dart:convert';

// class TestPage extends StatefulWidget {
//   const TestPage({super.key});

//   @override
//   State<TestPage> createState() => _TestPageState();
// }

// class _TestPageState extends State<TestPage> {
//   final TextEditingController formNameController = TextEditingController();
//   final TextEditingController descriptionController = TextEditingController();

//   // Questions
//   List<Map<String, dynamic>> questions = [];
//   String? selectedType = 'Single Choice';
//   List<String> options = [];
//   TextEditingController questionController = TextEditingController();
//   TextEditingController optionController = TextEditingController();
//   List<TextEditingController> optionControllers = [];

//   List<Map<String, dynamic>> formsList = [];

//   void init() {
//     super.initState();
//     DatabaseHelper.instance.initDatabase();
//     _loadForms();
//   }

//   Map<String, dynamic> deepCopyQuestion(Map<String, dynamic> originalQuestion) {
//     return {
//       'question': originalQuestion['question'],
//       'type': originalQuestion['type'],
//       'options': List<String>.from(originalQuestion['options']),
//     };
//   }

//   void addQuestion() {
//     if (questionController.text.isNotEmpty) {
//       final question = {
//         'question': questionController.text,
//         'type': selectedType,
//         'options': options,
//       };
//       Map<String, dynamic> q = deepCopyQuestion(question);
//       setState(() {
//         questions.add(q);
//         questionController.clear();
//         optionControllers.clear();
//         options.clear();
//         optionControllers.add(TextEditingController());
//       });
//     }
//   }

//   void saveQuestionsAsJson() async {
//     print(questions);
//     print(json.encode(questions));
//     final questionnaire = {'questions': questions};
//     final jsonText = json.encode(questionnaire);
//     print(jsonText);

//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('Successfully saved the form'),
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     questionController.dispose();
//     optionController.dispose();
//     super.dispose();
//   }

//   void _loadForms() async {
//     formsList = await DatabaseHelper.instance.getForms();
//     setState(() {});
//   }

//   void createForm() async {
//     String formName = formNameController.text;
//     String description = descriptionController.text;
//     String template = json.encode(questions);

//     await DatabaseHelper.instance.insertForm({
//       'Name': formName,
//       'Description': description,
//       'template_source': template
//     });
//     _loadForms();
//     _clearFields();
//   }

//   void _clearFields() async {
//     formNameController.clear();
//     descriptionController.clear();
//     questions.clear();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Create Form'),
//       ),
//       body: Stack(
//         children: <Widget>[
//           SingleChildScrollView(
//             child: Center(
//                 child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: <Widget>[
//                 Text('Enter Form Details'),
//                 SizedBox(
//                   height: 10,
//                 ),
//                 TextField(
//                   controller: formNameController,
//                   decoration: InputDecoration(labelText: 'Form Name'),
//                 ),
//                 TextField(
//                   controller: descriptionController,
//                   decoration: InputDecoration(labelText: 'Description'),
//                 ),
//                 const SizedBox(height: 16),
//                 const Text(
//                   'Select the type of question:',
//                   style: TextStyle(fontSize: 18),
//                 ),
//                 DropdownButton<String>(
//                   value: selectedType,
//                   icon: const Icon(Icons.arrow_drop_down),
//                   style: const TextStyle(color: Colors.blue, fontSize: 18),
//                   underline: Container(
//                     height: 2,
//                     color: Colors.blue,
//                   ),
//                   items: <String>[
//                     'Single Choice',
//                     'Multiple Choice',
//                     'Text Answer',
//                     'Integer Answer',
//                   ].map((String value) {
//                     return DropdownMenuItem<String>(
//                       value: value,
//                       child: Text(
//                         value,
//                         style: const TextStyle(fontSize: 18),
//                       ),
//                     );
//                   }).toList(),
//                   onChanged: (String? newValue) {
//                     setState(() {
//                       selectedType = newValue;
//                       options.clear();
//                     });
//                   },
//                 ),
//                 const Text(
//                   'Enter the question:',
//                   style: TextStyle(fontSize: 18),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.all(8.0),
//                   child: TextField(
//                     controller: questionController,
//                     decoration: const InputDecoration(
//                       labelText: 'Question',
//                       border: OutlineInputBorder(),
//                     ),
//                   ),
//                 ),
//                 if (selectedType == 'Single Choice' ||
//                     selectedType == 'Multiple Choice')
//                   Column(
//                     children: <Widget>[
//                       const Text(
//                         'Enter options:',
//                         style: TextStyle(fontSize: 18),
//                       ),
//                       for (var i = 0; i < options.length; i++)
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: TextField(
//                             controller: optionControllers[
//                                 i], // Use the respective controller
//                             onChanged: (text) {
//                               options[i] = text;
//                             },
//                             decoration:
//                                 InputDecoration(labelText: 'Option ${i + 1}'),
//                           ),
//                         ),
//                       ElevatedButton(
//                         onPressed: () {
//                           setState(() {
//                             options.add('');
//                             optionControllers.add(
//                                 TextEditingController()); // Add a new controller
//                           });
//                         },
//                         child: const Text('Add Option'),
//                       ),
//                     ],
//                   ),
//                 ElevatedButton(
//                   onPressed: addQuestion,
//                   child: const Text('Add Question'),
//                 ),
//                 ElevatedButton(
//                     onPressed: () {
//                       saveQuestionsAsJson();
//                     },
//                     child: Text('Print Questions')),
//                 ElevatedButton(
//                     onPressed: createForm, child: Text('Create Form')),
//                 ElevatedButton(
//                     onPressed: _loadForms, child: Text('Display Forms')),
//                 formsList.isNotEmpty
//                     ? SingleChildScrollView(
//                         scrollDirection: Axis.horizontal,
//                         child: DataTable(
//                           columns: const <DataColumn>[
//                             DataColumn(label: Text('sid')),
//                             DataColumn(label: Text('Name')),
//                             DataColumn(label: Text('Description')),
//                             DataColumn(label: Text('template_source')),
//                             DataColumn(label: Text('date_creation')),
//                           ],
//                           rows: formsList
//                               .map(
//                                 (form_) => DataRow(
//                                   cells: <DataCell>[
//                                     DataCell(Text(form_['sid'].toString())),
//                                     DataCell(Text(form_['Name'].toString())),
//                                     DataCell(
//                                         Text(form_['Description'].toString())),
//                                     DataCell(Text(
//                                         form_['template_source'].toString())),
//                                     DataCell(Text(
//                                         form_['creation_date'].toString())),
//                                   ],
//                                 ),
//                               )
//                               .toList(),
//                         ),
//                       )
//                     : Container(),
//               ],
//             )),
//           )
//         ],
//       ),
//     );
//   }
// }
