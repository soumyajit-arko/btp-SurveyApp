import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import 'dart:convert';

import 'login_page.dart';

class DesignExecutive extends StatefulWidget {
  const DesignExecutive({super.key});

  @override
  State<DesignExecutive> createState() => _DesignExecutiveState();
}

class _DesignExecutiveState extends State<DesignExecutive> {
  final TextEditingController formNameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  // Questions
  List<Map<String, dynamic>> questions = [];
  String? selectedType = 'Single Choice';
  List<String> options = [];
  TextEditingController questionController = TextEditingController();
  TextEditingController attributeUnitController = TextEditingController();
  bool isRequired = false;
  TextEditingController optionController = TextEditingController();
  List<TextEditingController> optionControllers = [];

  List<Map<String, dynamic>> formsList = [];
  List<Map<String, dynamic>> fieldsList = [];
  void init() {
    super.initState();
    DatabaseHelper.instance.initDatabase();
    _loadForms();
    _loadFields();
  }

  Map<String, dynamic> deepCopyQuestion(Map<String, dynamic> originalQuestion) {
    return {
      'question': originalQuestion['question'],
      'type': originalQuestion['type'],
      'unit': originalQuestion['unit'],
      'options': originalQuestion['options'],
      'required': originalQuestion['required']
    };
  }

  void addQuestion() {
    if (questionController.text.isNotEmpty) {
      final question = {
        'question': questionController.text,
        'type': selectedType,
        'unit': attributeUnitController.text,
        'options': options.join(','),
        'required': isRequired ? 1 : 0
      };
      Map<String, dynamic> q = deepCopyQuestion(question);
      setState(() {
        questions.add(q);
        questionController.clear();
        optionControllers.clear();
        options.clear();
        isRequired = false;
        attributeUnitController.clear();
        optionControllers.add(TextEditingController());
      });
    }
  }

  void saveQuestionsAsJson() async {
    // print(questions);
    // // print(json.encode(questions));
    // final questionnaire = {'questions': questions};
    // final jsonText = json.encode(questionnaire);
    // // print(jsonText);
    // questions.forEach((element) {
    //   print('I am printing : ');
    //   print(element['question']);
    //   print(element['type']);
    //   print(element['options']);
    // });
    String formName = formNameController.text;

    final sid = await DatabaseHelper.instance.getSidByName(formName);
    print('sid : ');
    print(sid);
    // ScaffoldMessenger.of(context).showSnackBar(
    //   SnackBar(
    //     content: Text('Successfully saved the form'),
    //   ),
    // );
  }

  @override
  void dispose() {
    questionController.dispose();
    optionController.dispose();
    super.dispose();
  }

  void _loadForms() async {
    formsList = await DatabaseHelper.instance.getForms();
    setState(() {});
  }

  void _loadFields() async {
    fieldsList = await DatabaseHelper.instance.getFields();
    print(fieldsList);
    setState(() {});
  }

  void createForm() async {
    String formName = formNameController.text;
    String description = descriptionController.text;
    String template = json.encode(questions);

    await DatabaseHelper.instance.insertForm({
      'Name': formName,
      'Description': description,
      'template_source': template
    });
    final sid = await DatabaseHelper.instance.getSidByName(formName);
    print('sid : ');
    print(sid);
    int sid_int = int.parse(sid);
    for (int i = 0; i < questions.length; ++i) {
      final Map<String, dynamic> element = questions[i];
      await DatabaseHelper.instance.insertField({
        'Name': formName,
        'sid': sid_int,
        'attribute_name': element['question'],
        'attribute_datatype': element['type'],
        'attribute_unit': element['unit'],
        'attribute_values': element['options'],
        'required_value': element['required'],
      });
    }

    _loadForms();
    _clearFields();
  }

  void _clearFields() async {
    formNameController.clear();
    descriptionController.clear();
    questions.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Form'),
      ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Center(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text('Enter Form Details'),
                SizedBox(
                  height: 10,
                ),
                TextField(
                  controller: formNameController,
                  decoration: InputDecoration(labelText: 'Form Name'),
                ),
                TextField(
                  controller: descriptionController,
                  decoration: InputDecoration(labelText: 'Description'),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Select the type of question:',
                  style: TextStyle(fontSize: 18),
                ),
                DropdownButton<String>(
                  value: selectedType,
                  icon: const Icon(Icons.arrow_drop_down),
                  style: const TextStyle(color: Colors.blue, fontSize: 18),
                  underline: Container(
                    height: 2,
                    color: Colors.blue,
                  ),
                  items: <String>[
                    'Single Choice',
                    'Multiple Choice',
                    'Text Answer',
                    'Integer Answer',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                        style: const TextStyle(fontSize: 18),
                      ),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedType = newValue;
                      options.clear();
                    });
                  },
                ),
                const Text(
                  'Enter the question:',
                  style: TextStyle(fontSize: 18),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: questionController,
                    decoration: const InputDecoration(
                      labelText: 'Question',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                TextField(
                  controller: attributeUnitController,
                  decoration: InputDecoration(labelText: 'Attribute Unit'),
                ),
                Row(
                  children: <Widget>[
                    Checkbox(
                      value: isRequired,
                      onChanged: (bool? newValue) {
                        setState(() {
                          isRequired = !isRequired;
                        });
                      },
                    ),
                    const Text(
                      'Required Value',
                      style: TextStyle(fontSize: 18),
                    ),
                  ],
                ),
                if (selectedType == 'Single Choice' ||
                    selectedType == 'Multiple Choice')
                  Column(
                    children: <Widget>[
                      const Text(
                        'Enter options:',
                        style: TextStyle(fontSize: 18),
                      ),
                      for (var i = 0; i < options.length; i++)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextField(
                            controller: optionControllers[
                                i], // Use the respective controller
                            onChanged: (text) {
                              options[i] = text;
                            },
                            decoration:
                                InputDecoration(labelText: 'Option ${i + 1}'),
                          ),
                        ),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            options.add('');
                            optionControllers.add(
                                TextEditingController()); // Add a new controller
                          });
                        },
                        child: const Text('Add Option'),
                      ),
                    ],
                  ),
                ElevatedButton(
                  onPressed: addQuestion,
                  child: const Text('Add Question'),
                ),
                ElevatedButton(
                    onPressed: () {
                      saveQuestionsAsJson();
                    },
                    child: Text('Print Questions')),
                ElevatedButton(
                    onPressed: createForm, child: Text('Create Form')),
                ElevatedButton(
                    onPressed: _loadForms, child: Text('Display Forms')),
                formsList.isNotEmpty
                    ? SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          columns: const <DataColumn>[
                            DataColumn(label: Text('sid')),
                            DataColumn(label: Text('Name')),
                            DataColumn(label: Text('Description')),
                            DataColumn(label: Text('template_source')),
                            DataColumn(label: Text('date_creation')),
                          ],
                          rows: formsList
                              .map(
                                (form_) => DataRow(
                                  cells: <DataCell>[
                                    DataCell(Text(form_['sid'].toString())),
                                    DataCell(Text(form_['Name'].toString())),
                                    DataCell(
                                        Text(form_['Description'].toString())),
                                    DataCell(Text(
                                        form_['template_source'].toString())),
                                    DataCell(Text(
                                        form_['creation_date'].toString())),
                                  ],
                                ),
                              )
                              .toList(),
                        ),
                      )
                    : Container(),
                ElevatedButton(
                    onPressed: _loadFields, child: Text('Display Fields')),
                fieldsList.isNotEmpty
                    ? SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          columns: const <DataColumn>[
                            DataColumn(label: Text('fid')),
                            DataColumn(label: Text('sid')),
                            DataColumn(label: Text('Name')),
                            DataColumn(label: Text('attribute_name')),
                            DataColumn(label: Text('attribute_datatype')),
                            DataColumn(label: Text('attribute_unit')),
                            DataColumn(label: Text('attribute_values')),
                            DataColumn(label: Text('required_value')),
                            DataColumn(label: Text('InstanceTime')),
                          ],
                          rows: fieldsList
                              .map(
                                (form_) => DataRow(
                                  cells: <DataCell>[
                                    DataCell(Text(form_['fid'].toString())),
                                    DataCell(Text(form_['sid'].toString())),
                                    DataCell(Text(form_['Name'].toString())),
                                    DataCell(Text(
                                        form_['attribute_name'].toString())),
                                    DataCell(Text(form_['attribute_datatype']
                                        .toString())),
                                    DataCell(Text(
                                        form_['attribute_unit'].toString())),
                                    DataCell(Text(
                                        form_['attribute_values'].toString())),
                                    DataCell(Text(
                                        form_['required_value'].toString())),
                                    DataCell(
                                        Text(form_['InstanceTime'].toString())),
                                  ],
                                ),
                              )
                              .toList(),
                        ),
                      )
                    : Container(),
              ],
            )),
          ),
          Positioned(
            top: 10, // Adjust top position as needed
            right: 10, // Adjust right position as needed
            child: ElevatedButton(
              onPressed: () {
                // Add the logic to log out here, navigate back to the login page
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          LoginPage()), // Redirect to LoginPage
                );
              },
              child: Text('Logout'),
            ),
          ),
        ],
      ),
    );
  }
}
