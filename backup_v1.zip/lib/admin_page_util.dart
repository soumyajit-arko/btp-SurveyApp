import 'package:flutter/material.dart';
import 'subject_register.dart';
import 'survey_page.dart';
import 'login_page.dart';

class SurveyorPageUtil extends StatefulWidget {
  @override
  _SurveyorPageUtilState createState() => _SurveyorPageUtilState();
}

class _SurveyorPageUtilState extends State<SurveyorPageUtil> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
      ),
      body: Stack(
        children: <Widget>[
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SubjectRegister()));
                  },
                  child: Text('Register New Subject'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SurveyorPage(100)));
                  },
                  child: Text('Take Survey'),
                ),
                Positioned(
                  top: 10, // Adjust top position as needed
                  right: 10, // Adjust right position as needed
                  child: ElevatedButton(
                    onPressed: () {
                      // Add the logic to log out here, navigate back to the login page
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              LoginPage(), // Redirect to LoginPage
                        ),
                      );
                    },
                    child: Text('Logout'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
