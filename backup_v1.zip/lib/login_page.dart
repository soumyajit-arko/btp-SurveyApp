import 'package:flutter/material.dart';
import 'database_helper.dart'; // Import your database helper
import 'design_executive.dart';
import 'survey_page.dart';
import 'admin_page.dart';
import 'survery_page_util.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  String? selectedUserType;
  List<String> userTypes = [
    'Admin',
    'Center Admin',
    'Surveyor',
    'Design Executive'
  ];

  void handleLogin() async {
    String username = usernameController.text;
    String password = passwordController.text;

    // Replace 'DatabaseHelper' with your actual database helper class
    final databaseHelper = DatabaseHelper.instance;

    // Add your database query here to check if the user exists
    // For example, you can use a query like:
    final user =
        await databaseHelper.getUser(username, password, selectedUserType);

    if (user != null) {
      // User exists, handle the login success
      print('Login successful for user: ${user['Name']}');

      // Add navigation logic here based on the user's type
      if (selectedUserType == 'Admin') {
        // Navigate to the AdminPage
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => AdminPage()),
        );
      }
      //else if (selectedUserType == 'Center Admin') {
      //   // Navigate to the CenterAdminPage
      //   Navigator.pushReplacement(
      //     context,
      //     MaterialPageRoute(builder: (context) => CenterAdminPage()),
      //   );
      // }
      else if (selectedUserType == 'Surveyor') {
        // Navigate to the SurveyorPage
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => SurveyorPageUtil()),
        );
      } else if (selectedUserType == 'Design Executive') {
        // Navigate to the DesignExecutivePage
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => DesignExecutive()),
        );
      } else {
        // Handle other user types or show an error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Incorrect credentials!!!'),
          ),
        );
      }
    } else {
      // User doesn't exist, handle the login failure
      print('Login failed. User not found.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'SURVEY PROJECT', // Add the heading here
              style: TextStyle(
                fontSize: 24, // Adjust the font size
                fontWeight: FontWeight.bold,
              ),
            ),
            Image.asset(
              'assets/images/login_bg.png',
              width: 150,
              height: 150,
            ),
            SizedBox(height: 20),
            DropdownButton<String>(
              hint: Text('Select User Type'),
              value: selectedUserType,
              items: userTypes.map((String userType) {
                return DropdownMenuItem<String>(
                  value: userType,
                  child: Text(userType),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedUserType = newValue;
                });
              },
            ),
            SizedBox(height: 20),
            TextField(
              controller: usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true, // Hide password characters
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: handleLogin,
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}
