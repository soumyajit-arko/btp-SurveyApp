import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  // Define the table names and column names
  static const String surveyProjectTable = 'survey_project';
  static const String fieldProjectTable = 'field_project';

  // Define column names for the survey_project table
  static const String surveyName = 'Name';
  static const String surveyId = 'sid';
  static const String creationDate = 'creation_date';
  static const String description = 'Description';
  static const String templateSource = 'template_source';

  // Define column names for the field_project table
  static const String fieldName = 'Name';
  static const String fieldId = 'fid';
  static const String surveyIdFk = 'sid';
  static const String attributeName = 'attribute_name';
  static const String attributeDatatype = 'attribute_datatype';
  static const String attributeUnit = 'attribute_unit';
  static const String requiredValue = 'required_value';
  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await initDatabase();
    return _database!;
  }

  Future<Database> initDatabase() async {
    final dbpath = await getDatabasesPath();
    print(dbpath);
    String path = join(dbpath, 'storage.db');
    return await openDatabase(path, version: 1, onCreate: _createDb);
  }

  Future<bool> _isTableExists(Database db, String tableName) async {
    final result = await db.rawQuery('''
    SELECT name FROM sqlite_master WHERE type='table' AND name=?
  ''', [tableName]);
    return result.isNotEmpty;
  }

  Future<void> _createDb(Database db, int version) async {
    // await db.execute('''
    //   CREATE TABLE questions(
    //     id INTEGER PRIMARY KEY AUTOINCREMENT,
    //     question TEXT,
    //     type TEXT,
    //     options TEXT
    //   )
    // ''');
    final tableExists = await _isTableExists(db, 'users');
    if (!tableExists) {
      await db.execute('''
      CREATE TABLE users (
        Name TEXT,
        Userid TEXT PRIMARY KEY,
        Password TEXT,
        Age INTEGER,
        Sex TEXT,
        Center_code TEXT,
        User_Type TEXT,
        Address TEXT,
        Mobile TEXT UNIQUE,
        Email TEXT UNIQUE,
        Instance_time TEXT
      )
    ''');

      await db.rawInsert('''
      INSERT INTO users (Name, Userid,Password, Age, Sex, Center_code, User_Type, Address, Mobile, Email, Instance_time)
      VALUES (?, ?, ?, ?, ?, ?, ?,?, ?, ?, CURRENT_TIMESTAMP)
    ''', [
        'admin',
        'admin123',
        'admin123',
        30,
        'Male',
        'Center123',
        'Admin',
        '123 Main St',
        '1234567890',
        'admin@example.com'
      ]);
      print('added user');
      await db.rawInsert('''
      INSERT INTO users (Name, Userid, Password,Age, Sex, Center_code, User_Type, Address, Mobile, Email, Instance_time)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,CURRENT_TIMESTAMP)
    ''', [
        'design_executive',
        'design123',
        'design123',
        35,
        'Female',
        'Center456',
        'Design Executive',
        '456 Elm St',
        '9876543210',
        'design@example.com'
      ]);
      print('added another user');
    }

    final surveyProjectExists = await _isTableExists(db, 'survey_project');
    if (!surveyProjectExists) {
      await db.execute('''
          CREATE TABLE survey_project (
            Name TEXT,
            sid TEXT PRIMARY KEY,
            creation_date TEXT,
            Description TEXT,
            template_source TEXT,
            InstanceTIme TEXT
          )
        ''');
      print('Created survey project');
    }

    final fieldProjectExists = await _isTableExists(db, 'field_project');
    if (!fieldProjectExists) {
      await db.execute('''
          CREATE TABLE survey_project (
            Name TEXT,
            fid TEXT PRIMARY KEY,
            sid TEXT FOREIGN KEY,
            attribute_name TEXT,
            attribute_datatype TEXT,
            attribute_unit TEXT,
            required_value INTEGER,
            InstanceTIme TEXT
          )
        ''');
      print('created field_project');
    }
  }

  // Insert a new question
  Future<int> insertQuestion(Map<String, dynamic> question) async {
    final db = await database;
    return await db.insert('questions', question);
  }

  // Update an existing question
  Future<int> updateQuestion(
      int id, Map<String, dynamic> updatedQuestion) async {
    final db = await database;
    return await db
        .update('questions', updatedQuestion, where: 'id = ?', whereArgs: [id]);
  }

  // Delete a question
  Future<int> deleteQuestion(int id) async {
    final db = await database;
    return await db.delete('questions', where: 'id = ?', whereArgs: [id]);
  }

  // Retrieve all questions
  Future<List<Map<String, dynamic>>> getQuestions() async {
    final db = await database;
    return await db.query('questions');
  }

  Future<Map<String, dynamic>?> getUser(
      String username, String password, String? userType) async {
    final db = await database;

    // Replace 'users' with the actual name of your users table
    final List<Map<String, dynamic>> users = await db.query(
      'users',
      where: 'Userid = ? AND Password = ? AND User_Type = ?',
      whereArgs: [username, password, userType],
    );

    if (users.isNotEmpty) {
      // Return the first user (assuming usernames are unique)
      return users.first;
    } else {
      return null; // User not found
    }
  }

  Future<int> insertUser(Map<String, dynamic> user) async {
    final db = await database;
    return await db.insert('users', user);
  }

  Future<List<Map<String, dynamic>>> getUsers() async {
    final db = await database;
    return await db.query('users');
  }

  Future<Map<String, dynamic>?> getUserById(String userId) async {
    final db = await database;
    final users = await db.query(
      'users',
      where: 'Userid = ?',
      whereArgs: [userId],
    );
    if (users.isNotEmpty) {
      return users.first;
    }
    return null;
  }

  Future<int> updateUser(
      String userId, Map<String, dynamic> updatedUser) async {
    final db = await database;
    return await db.update(
      'users',
      updatedUser,
      where: 'Userid = ?',
      whereArgs: [userId],
    );
  }

  Future<int> deleteUser(String userId) async {
    final db = await database;
    return await db.delete(
      'users',
      where: 'Userid = ?',
      whereArgs: [userId],
    );
  }

  Future<void> insertSurvey(Map<String, dynamic> survey) async {
    final db = await database;
    await db.insert(surveyProjectTable, survey,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> getSurveyNames() async {
    final db = await database;
    return await db.query(surveyProjectTable,
        columns: [surveyName, surveyId], orderBy: '$creationDate DESC');
  }

  Future<Map<String, dynamic>> getSurveyDetails(String surveyId) async {
    final db = await database;
    final result = await db.query(surveyProjectTable,
        where: '$surveyId = ?', whereArgs: [surveyId], limit: 1);
    return result.isNotEmpty ? result.first : Map<String, dynamic>();
  }

  Future<Map<String, dynamic>?> getSurveyForm(String surveyName) async {
    final db = await database;
    final maps = await db.query(
      'survey_project',
      where: 'Name = ?',
      whereArgs: [surveyName],
    );
    if (maps.isNotEmpty) {
      return maps.first;
    }
    return null;
  }

  Future<int> insertSurveyForm(Map<String, dynamic> surveyForm) async {
    final db = await database;
    return await db.insert('survey_project', surveyForm);
  }
}
