// import 'package:flutter/material.dart';
// import 'dart:convert';
// import 'database_helper.dart';
// import 'dart:io';
// import 'package:uuid/uuid.dart';

// class QuestionnaireBuilder extends StatefulWidget {
//   @override
//   _QuestionnaireBuilderState createState() => _QuestionnaireBuilderState();
// }

// class _QuestionnaireBuilderState extends State<QuestionnaireBuilder> {
//   // Survey project information
//   String? surveyProjectName;
//   String? surveyProjectSid;
//   String? surveyProjectDescription;

//   // Questions
//   List<Map<String, dynamic>> questions = [];
//   String? selectedType = 'Single Choice';
//   List<String> options = [];
//   TextEditingController questionController = TextEditingController();
//   TextEditingController optionController = TextEditingController();
//   List<TextEditingController> optionControllers = [];

//   @override
//   void initState() {
//     super.initState();

//     DatabaseHelper.instance.initDatabase();
//   }

//   @override
//   void dispose() {
//     questionController.dispose();
//     optionController.dispose();
//     super.dispose();
//   }

//   Map<String, dynamic> deepCopyQuestion(Map<String, dynamic> originalQuestion) {
//     return {
//       'question': originalQuestion['question'],
//       'type': originalQuestion['type'],
//       'options': List<String>.from(originalQuestion['options']),
//     };
//   }

//   void addQuestion() {
//     if (questionController.text.isNotEmpty) {
//       final question = {
//         'question': questionController.text,
//         'type': selectedType,
//         'options': options,
//       };
//       Map<String, dynamic> q = deepCopyQuestion(question);
//       setState(() {
//         questions.add(q);
//         questionController.clear();
//         optionControllers.clear();
//         options.clear();
//         optionControllers.add(TextEditingController());
//       });
//     }
//   }

//   void saveQuestionsAsJson(BuildContext context) async {
//     final questionnaire = {'questions': questions};
//     final jsonText = json.encode(questionnaire);
//     print(jsonText);
//     final file = File('assets/survey_questions.json');
//     await file.writeAsString(jsonText);

//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('Questionnaire saved as JSON file.'),
//       ),
//     );
//   }

//   Future<void> saveQuestionsToDatabase() async {
//     final database = await DatabaseHelper.instance.database;
//     final batch = database.batch();

//     // Insert survey project information into survey_project table
//     final surveyProject = {
//       'Name': surveyProjectName,
//       'sid': surveyProjectSid,
//       'Description': surveyProjectDescription,
//       'template_source': jsonEncode(questions),
//     };
//     batch.insert('survey_project', surveyProject);

//     // Insert individual questions into field_project table
//     for (final question in questions) {
//       batch.insert('field_project', {
//         'name': question['question'],
//         'fid': Uuid().v4(), // Use a UUID for the field ID
//         'sid': surveyProjectSid,
//         'attribute_name': question['question'],
//         'attribute_datatype': question['type'],
//         'attribute_unit': 'N/A', // You can customize this
//         'required_value': true, // You can customize this
//       });
//     }

//     await batch.commit();
//     print('Survey project and questions saved successfully in the database');
//   }

//   Future<void> createSurveyProject() async {
//     // Collect project details (Name, SID, Description) from the user
//     final String projectName = "Your Project Name"; // Replace with user input
//     final String sid = "Your SID"; // Replace with user input
//     final String description =
//         "Your Project Description"; // Replace with user input

//     // Create a map to store survey project details
//     final Map<String, dynamic> surveyProject = {
//       'Name': projectName,
//       'sid': sid,
//       'Description': description,
//       'template_source': '', // Initialize to an empty string for now
//     };

//     // Insert survey project details into the database
//     await DatabaseHelper.instance.insertSurveyProject(surveyProject);

//     // Now you can allow users to add questions
//   }

//   Future<void> retrieveDataFromDatabase() async {
//     final database = await DatabaseHelper.instance.database;

//     // Retrieve survey project from survey_project table
//     final surveyProjectList = await database.query('survey_project');
//     if (surveyProjectList.isNotEmpty) {
//       final surveyProject = surveyProjectList.first;
//       final surveyProjectName =
//           surveyProject['Name'] as String; // Cast to String
//       final surveyProjectDescription =
//           surveyProject['Description'] as String; // Cast to String
//       final surveyProjectQuestions =
//           surveyProject['template_source'] as String; // Cast to String

//       print('Survey Project Name: $surveyProjectName');
//       print('Survey Project Description: $surveyProjectDescription');
//       print('Survey Project Questions: $surveyProjectQuestions');
//     } else {
//       print('No survey project found.');
//       return;
//     }

//     // Retrieve individual questions from field_project table
//     final fieldProjectList = await database.query('field_project');
//     if (fieldProjectList.isNotEmpty) {
//       print('Individual Questions:');
//       for (final fieldProject in fieldProjectList) {
//         final questionName =
//             fieldProject['attribute_name'] as String; // Cast to String
//         print('Question Name: $questionName');
//       }
//     } else {
//       print('No individual questions found.');
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SingleChildScrollView(
//         child: Column(
//           children: <Widget>[
//             const Text(
//               'Enter Survey Project Information:',
//               style: TextStyle(fontSize: 18),
//             ),
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: TextField(
//                 onChanged: (value) {
//                   surveyProjectName = value;
//                 },
//                 decoration: const InputDecoration(
//                   labelText: 'Survey Project Name',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: TextField(
//                 onChanged: (value) {
//                   surveyProjectSid = value;
//                 },
//                 decoration: const InputDecoration(
//                   labelText: 'Survey Project SID',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: TextField(
//                 onChanged: (value) {
//                   surveyProjectDescription = value;
//                 },
//                 decoration: const InputDecoration(
//                   labelText: 'Survey Project Description',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//             ),
//             ElevatedButton(
//               onPressed: () async {
//                 // Save survey project information and questions
//                 await saveQuestionsToDatabase();
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(
//                     content: Text(
//                         'Survey project and questions saved to the database.'),
//                   ),
//                 );
//               },
//               child:
//                   const Text('Save Survey Project and Questions to Database'),
//             ),
//             ElevatedButton(
//               onPressed: () async {
//                 await createSurveyProject();
//               },
//               child: const Text('Create Survey Project'),
//             ),
//             const SizedBox(height: 16),
//             const Text(
//               'Select the type of question:',
//               style: TextStyle(fontSize: 18),
//             ),
//             DropdownButton<String>(
//               value: selectedType,
//               icon: const Icon(Icons.arrow_drop_down),
//               style: const TextStyle(color: Colors.blue, fontSize: 18),
//               underline: Container(
//                 height: 2,
//                 color: Colors.blue,
//               ),
//               items: <String>[
//                 'Single Choice',
//                 'Multiple Choice',
//                 'Text Answer',
//                 'Integer Answer',
//               ].map((String value) {
//                 return DropdownMenuItem<String>(
//                   value: value,
//                   child: Text(
//                     value,
//                     style: const TextStyle(fontSize: 18),
//                   ),
//                 );
//               }).toList(),
//               onChanged: (String? newValue) {
//                 setState(() {
//                   selectedType = newValue;
//                   options.clear();
//                 });
//               },
//             ),
//             const Text(
//               'Enter the question:',
//               style: TextStyle(fontSize: 18),
//             ),
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: TextField(
//                 controller: questionController,
//                 decoration: const InputDecoration(
//                   labelText: 'Question',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//             ),
//             if (selectedType == 'Single Choice' ||
//                 selectedType == 'Multiple Choice')
//               Column(
//                 children: <Widget>[
//                   const Text(
//                     'Enter options:',
//                     style: TextStyle(fontSize: 18),
//                   ),
//                   for (var i = 0; i < options.length; i++)
//                     Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: TextField(
//                         controller: optionControllers[
//                             i], // Use the respective controller
//                         onChanged: (text) {
//                           options[i] = text;
//                         },
//                         decoration:
//                             InputDecoration(labelText: 'Option ${i + 1}'),
//                       ),
//                     ),
//                   ElevatedButton(
//                     onPressed: () {
//                       setState(() {
//                         options.add('');
//                         optionControllers.add(
//                             TextEditingController()); // Add a new controller
//                       });
//                     },
//                     child: const Text('Add Option'),
//                   ),
//                 ],
//               ),
//             ElevatedButton(
//               onPressed: addQuestion,
//               child: const Text('Add Question'),
//             ),
//             ElevatedButton(
//               onPressed: () {
//                 saveQuestionsAsJson(context);
//               },
//               child: const Text('Save Questions as JSON'),
//             ),
//             ElevatedButton(
//               onPressed: () async {
//                 await saveQuestionsToDatabase();
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(
//                     content: Text('Questionnaire saved to the database.'),
//                   ),
//                 );
//               },
//               child: const Text('Save Questions to Database'),
//             ),
//             ElevatedButton(
//               onPressed: () async {
//                 await retrieveDataFromDatabase();
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(
//                     content: Text('Questionnaire retrieved from the database.'),
//                   ),
//                 );
//               },
//               child: const Text('Retrieve Questions from Database'),
//             ),
//             if (questions.isNotEmpty)
//               Column(
//                 children: <Widget>[
//                   const Text(
//                     'Questions:',
//                     style: TextStyle(fontSize: 20),
//                   ),
//                   ListView.builder(
//                     shrinkWrap: true,
//                     itemCount: questions.length,
//                     itemBuilder: (context, index) {
//                       final question = questions[index];
//                       final type = question['type'];
//                       final questionText = question['question'];
//                       final optionsList = question['options'] as List<String>;

//                       return ListTile(
//                         title: Text('Question: $questionText'),
//                         subtitle: Text(
//                             'Type: $type\nOptions: ${optionsList.join(", ")}'),
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ElevatedButton(
//               onPressed: () {
//                 // Navigate back to the main page when the "Go Back" button is pressed
//                 Navigator.of(context).pop();
//               },
//               child: const Text('Go Back to Main Page'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
