// Existing imports
import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'package:intl/intl.dart';
import 'login_page.dart';

class AdminPage extends StatefulWidget {
  @override
  _AdminPageState createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController userIdController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController sexController = TextEditingController();
  final TextEditingController centerCodeController = TextEditingController();
  final TextEditingController userTypeController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  List<Map<String, dynamic>> users = [];

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  void _loadUsers() async {
    users = await DatabaseHelper.instance.getUsers();
    setState(() {});
  }

  void addUser() async {
    String name = nameController.text;
    String userId = userIdController.text;
    String password = passwordController.text;
    int age = int.tryParse(ageController.text) ?? 0;
    String sex = sexController.text;
    String centerCode = centerCodeController.text;
    String userType = userTypeController.text;
    String address = addressController.text;
    String mobile = mobileController.text;
    String email = emailController.text;
    dynamic currentTime = DateFormat.jm().format(DateTime.now());

    await DatabaseHelper.instance.insertUser({
      'Name': name,
      'Userid': userId,
      'Password': password,
      'Age': age,
      'Sex': sex,
      'Center_code': centerCode,
      'User_Type': userType,
      'Address': address,
      'Mobile': mobile,
      'Email': email,
      'Instance_time': currentTime,
    });

    // Reload the user list
    _loadUsers();

    // Clear text fields
    _clearFields();
    // print('Done');
  }

  void _clearFields() {
    nameController.clear();
    userIdController.clear();
    passwordController.clear();
    ageController.clear();
    sexController.clear();
    centerCodeController.clear();
    userTypeController.clear();
    addressController.clear();
    mobileController.clear();
    emailController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Page'),
      ),
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Create a New User',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(labelText: 'Name'),
                  ),
                  TextField(
                    controller: userIdController,
                    decoration: InputDecoration(labelText: 'User ID'),
                  ),
                  TextField(
                    controller: passwordController,
                    decoration: InputDecoration(labelText: 'Password'),
                  ),
                  TextField(
                    controller: ageController,
                    decoration: InputDecoration(labelText: 'Age'),
                    keyboardType: TextInputType.number,
                  ),
                  TextField(
                    controller: sexController,
                    decoration: InputDecoration(labelText: 'Sex'),
                  ),
                  TextField(
                    controller: centerCodeController,
                    decoration: InputDecoration(labelText: 'Center Code'),
                  ),
                  TextField(
                    controller: userTypeController,
                    decoration: InputDecoration(labelText: 'User Type'),
                  ),
                  TextField(
                    controller: addressController,
                    decoration: InputDecoration(labelText: 'Address'),
                  ),
                  TextField(
                    controller: mobileController,
                    decoration: InputDecoration(labelText: 'Mobile'),
                    keyboardType: TextInputType.phone,
                  ),
                  TextField(
                    controller: emailController,
                    decoration: InputDecoration(labelText: 'Email'),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: addUser,
                    child: Text('Create User'),
                  ),
                  // Display Users button (same as before)
                  SizedBox(height: 20),
                  Text(
                    'Display Details of Users',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      _loadUsers(); // Reload the user list
                    },
                    child: Text('Display Users'),
                  ),
                  users.isNotEmpty
                      ? SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            columns: const <DataColumn>[
                              DataColumn(
                                label: Text('Name'),
                              ),
                              DataColumn(
                                label: Text('User ID'),
                              ),
                              DataColumn(
                                label: Text('Age'),
                              ),
                              DataColumn(
                                label: Text('Sex'),
                              ),
                              DataColumn(
                                label: Text('Center Code'),
                              ),
                              DataColumn(
                                label: Text('User Type'),
                              ),
                              DataColumn(
                                label: Text('Address'),
                              ),
                              DataColumn(
                                label: Text('Mobile'),
                              ),
                              DataColumn(
                                label: Text('Email'),
                              ),
                            ],
                            rows: users
                                .map(
                                  (user) => DataRow(
                                    cells: <DataCell>[
                                      DataCell(Text(user['Name'].toString())),
                                      DataCell(Text(user['Userid'].toString())),
                                      DataCell(Text(user['Age'].toString())),
                                      DataCell(Text(user['Sex'].toString())),
                                      DataCell(
                                          Text(user['Center_code'].toString())),
                                      DataCell(
                                          Text(user['User_Type'].toString())),
                                      DataCell(
                                          Text(user['Address'].toString())),
                                      DataCell(Text(user['Mobile'].toString())),
                                      DataCell(Text(user['Email'].toString())),
                                    ],
                                  ),
                                )
                                .toList(),
                          ),
                        )
                      : Container(),
                ],
              ),
            ),
          ),
          Positioned(
            top: 10, // Adjust top position as needed
            right: 10, // Adjust right position as needed
            child: ElevatedButton(
              onPressed: () {
                // Add the logic to log out here, navigate back to the login page
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          LoginPage()), // Redirect to LoginPage
                );
              },
              child: Text('Logout'),
            ),
          ),
        ],
      ),
    );
  }
}
