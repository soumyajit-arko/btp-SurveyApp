// import 'package:flutter/material.dart';
// import 'database_helper.dart';

// class DesignExecutive extends StatefulWidget {
//   @override
//   _DesignExecutiveState createState() => _DesignExecutiveState();
// }

// class _DesignExecutiveState extends State<DesignExecutive> {
//   final TextEditingController nameController = TextEditingController();
//   final TextEditingController descriptionController = TextEditingController();
//   List<Map<String, dynamic>> questions = [];
//   String selectedSurveyName = '';
//   List<Map<String, dynamic>> surveyNames = [];
//   final TextEditingController questionController = TextEditingController();
//   List<TextEditingController> optionControllers = [TextEditingController()];

//   @override
//   void initState() {
//     super.initState();
//     _loadSurveyNames();
//   }

//   void _loadSurveyNames() async {
//     final surveyNamesList = await DatabaseHelper.instance.getSurveyNames();
//     print(surveyNamesList);
//     // surveyNames = surveyNamesList
//     //     .map((map) => map['Name'].toString())
//     //     .cast<Map<String, dynamic>>()
//     //     .toList();
//     // setState(() {});
//   }

//   void addQuestion() {
//     if (questionController.text.isNotEmpty) {
//       final question = {
//         'question': questionController.text,
//         'options': optionControllers
//             .map((controller) => controller.text)
//             .where((option) => option.isNotEmpty)
//             .toList(),
//       };
//       setState(() {
//         questions.add(question);
//         questionController.clear();
//         optionControllers.clear();
//         optionControllers.add(TextEditingController());
//       });
//     }
//   }

//   void submitSurveyForm() async {
//     if (nameController.text.isNotEmpty) {
//       final surveyForm = {
//         'name': nameController.text,
//         'description': descriptionController.text,
//         'questions': questions,
//       };

//       await DatabaseHelper.instance.insertSurveyForm(surveyForm);

//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text('Survey form saved to the database.'),
//         ),
//       );

//       setState(() {
//         questions.clear();
//         nameController.clear();
//         descriptionController.clear();
//       });
//     }
//   }

//   @override
//   void dispose() {
//     nameController.dispose();
//     descriptionController.dispose();
//     questionController.dispose();
//     for (final controller in optionControllers) {
//       controller.dispose();
//     }
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Design Executive'),
//       ),
//       body: SingleChildScrollView(
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: <Widget>[
//             const SizedBox(height: 20),
//             Text(
//               'Create a Survey Form',
//               style: TextStyle(
//                 fontSize: 20,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             TextField(
//               controller: nameController,
//               decoration: InputDecoration(labelText: 'Survey Name'),
//             ),
//             TextField(
//               controller: descriptionController,
//               decoration: InputDecoration(labelText: 'Description'),
//             ),
//             Text(
//               'Enter Questions and Options',
//               style: TextStyle(
//                 fontSize: 16,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             if (questions.isNotEmpty)
//               Column(
//                 children: <Widget>[
//                   for (var i = 0; i < questions.length; i++)
//                     Column(
//                       children: <Widget>[
//                         TextField(
//                           controller: questionController,
//                           decoration: InputDecoration(labelText: 'Question'),
//                         ),
//                         for (var j = 0; j < optionControllers.length; j++)
//                           TextField(
//                             controller: optionControllers[j],
//                             decoration: InputDecoration(
//                               labelText: 'Option ${j + 1}',
//                             ),
//                           ),
//                         ElevatedButton(
//                           onPressed: addQuestion,
//                           child: Text('Add Question'),
//                         ),
//                       ],
//                     ),
//                   ElevatedButton(
//                     onPressed: submitSurveyForm,
//                     child: Text('Submit Survey Form'),
//                   ),
//                 ],
//               ),
//             const SizedBox(height: 20),
//             Text(
//               'View a Survey Form',
//               style: TextStyle(
//                 fontSize: 20,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             // DropdownButton<String>(
//             //   hint: Text('Select Survey Name'),
//             //   value: selectedSurveyName,
//             //   items: (surveyNames as List<String>).map((String name) {
//             //     return DropdownMenuItem<String>(
//             //       value: name,
//             //       child: Text(name),
//             //     );
//             //   }).toList(),
//             //   onChanged: (String? newValue) {
//             //     setState(() {
//             //       selectedSurveyName = newValue!;
//             //     });
//             //   },
//             // ),
//             // if (selectedSurveyName.isNotEmpty)
//             //   ElevatedButton(
//             //     onPressed: () async {
//             //       final surveyForm = await DatabaseHelper.instance
//             //           .getSurveyForm(selectedSurveyName);
//             //       showDialog(
//             //         context: context,
//             //         builder: (context) {
//             //           return AlertDialog(
//             //             title: Text('Survey Form Details'),
//             //             content: Column(
//             //               crossAxisAlignment: CrossAxisAlignment.start,
//             //               children: [
//             //                 Text('Name: ${surveyForm?['name']}'),
//             //                 Text('Description: ${surveyForm?['description']}'),
//             //                 Text('Questions:'),
//             //                 for (final question
//             //                     in surveyForm?['questions']) ...[
//             //                   Text(' - ${question['question']}'),
//             //                   if (question['options'] != null)
//             //                     for (final option in question['options'])
//             //                       Text('   - $option'),
//             //                 ],
//             //               ],
//             //             ),
//             //             actions: [
//             //               TextButton(
//             //                 onPressed: () {
//             //                   Navigator.of(context).pop();
//             //                 },
//             //                 child: Text('Close'),
//             //               ),
//             //             ],
//             //           );
//             //         },
//             //       );
//             //     },
//             //     child: Text('View Survey Form Details'),
//             //   ),
//             const SizedBox(height: 20),
//           ],
//         ),
//       ),
//     );
//   }
// }
