import 'dart:convert';
import 'dart:io'; // Import 'dart:io' for file operations
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SurveyorPage extends StatefulWidget {
  @override
  _SurveyorPageState createState() => _SurveyorPageState();
}

class _SurveyorPageState extends State<SurveyorPage> {
  List<Map<String, dynamic>> questions = [];
  Map<String, dynamic> responses = {};

  @override
  void initState() {
    super.initState();
    loadSurveyQuestions();
  }

  Future<void> loadSurveyQuestions() async {
    // Load the JSON file from assets
    String jsonContent =
        await rootBundle.loadString('assets/survey_questions.json');
    Map<String, dynamic> surveyData = json.decode(jsonContent);

    setState(() {
      questions = List<Map<String, dynamic>>.from(surveyData['questions']);
    });
  }

  void handleOptionSelected(String question, String selectedOption) {
    setState(() {
      responses[question] = selectedOption;
    });
  }

  void handleMultipleChoiceOptionSelected(
      String question, String option, bool selected) {
    setState(() {
      if (responses[question] != null) {
        // If a response already exists, append the new option with a comma
        responses[question] = '${responses[question]}, $option';
      } else {
        responses[question] = option;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Survey Questions'),
      ),
      body: ListView.builder(
        itemCount: questions.length,
        itemBuilder: (context, index) {
          final question = questions[index];
          final questionText = question['question'];
          final questionType = question['type'];
          final options = question['options'];
          Widget? questionWidget;
          if (questionType == 'Single Choice') {
            questionWidget = Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(questionText, style: TextStyle(fontSize: 18)),
                for (var option in options)
                  RadioListTile<String>(
                    title: Text(option),
                    value: option,
                    groupValue: responses[questionText],
                    onChanged: (value) {
                      handleOptionSelected(questionText, value ?? '');
                    },
                  ),
              ],
            );
          } else if (questionType == 'Multiple Choice') {
            questionWidget = Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(questionText, style: TextStyle(fontSize: 18)),
                for (var option in options)
                  CheckboxListTile(
                    title: Text(option),
                    value: responses[questionText]?.contains(option) ?? false,
                    onChanged: (selected) {
                      if (selected != null) {
                        handleMultipleChoiceOptionSelected(
                            questionText, option, selected);
                      }
                    },
                  ),
              ],
            );
          } else if (questionType == 'Text Answer' ||
              questionType == 'Integer Answer') {
            questionWidget = Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(questionText, style: TextStyle(fontSize: 18)),
                TextField(
                  onChanged: (value) {
                    handleOptionSelected(questionText, value);
                  },
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(hintText: 'Enter your answer'),
                ),
              ],
            );
          }

          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: questionWidget,
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          saveResponsesToJson();
        },
        child: const Icon(Icons.save),
      ),
    );
  }

  bool isNumeric(String value) {
    if (value.isEmpty) {
      return true; // Allow empty input
    }
    final num? number = num.tryParse(value);
    return number != null;
  }

  Future<void> saveResponsesToJson() async {
    final responsesMap = Map<String, dynamic>.from(responses);
    final responsesJson = json.encode(responsesMap);

    // final directory = await getApplicationDocumentsDirectory();
    final file = File('assets/survey_responses.json');

    await file.writeAsString(responsesJson);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Responses saved as JSON file.'),
      ),
    );
  }
}




