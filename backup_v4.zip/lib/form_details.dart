class FormDetails {
  final String formName;

  FormDetails({required this.formName});
}